In order to install the ImageIO-Ext GDAL extensions you have to:

* Copy all the jars contained in this package into geoserver/WEB-INF/lib
* Properly install the native binary libraries for your operating system

For the binary components and install instructions referer to:
http://docs.geoserver.org/latest/en/user/data/raster/gdal.html